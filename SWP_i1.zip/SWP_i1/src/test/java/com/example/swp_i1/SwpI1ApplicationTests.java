package com.example.swp_i1;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SwpI1ApplicationTests {

    @Test
    void contextLoads() {
    }

}
