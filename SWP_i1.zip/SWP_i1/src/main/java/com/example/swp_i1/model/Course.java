package com.example.swp_i1.model;

import jakarta.persistence.*;

@Entity
@Table(name = "courses")
public class Course {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    private String name;
    private String category;

    @Column(name = "number_of_lessons")
    private int numberOfLessons;

    private String owner;
    private String status;

    public Course() {}

    public Course(String name, String category, int numberOfLessons, String owner, String status) {
        this.name = name;
        this.category = category;
        this.numberOfLessons = numberOfLessons;
        this.owner = owner;
        this.status = status;
    }

    // getters & setters
    public Long getId() { return id; }
    public void setId(Long id) { this.id = id; }

    public String getName() { return name; }
    public void setName(String name) { this.name = name; }

    public String getCategory() { return category; }
    public void setCategory(String category) { this.category = category; }

    public int getNumberOfLessons() { return numberOfLessons; }
    public void setNumberOfLessons(int numberOfLessons) { this.numberOfLessons = numberOfLessons; }

    public String getOwner() { return owner; }
    public void setOwner(String owner) { this.owner = owner; }

    public String getStatus() { return status; }
    public void setStatus(String status) { this.status = status; }
}
