package com.example.swp_i1.controller;

import com.example.swp_i1.service.CourseService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@Controller
public class CourseController {
    @Autowired
    private CourseService service;

    @GetMapping({"/courses", "/"})
    public String viewCourses(
            @RequestParam(defaultValue = "0") int page,
            @RequestParam(defaultValue = "5") int size,
            @RequestParam(required = false) String category,
            @RequestParam(required = false) String status,
            @RequestParam(required = false) String search,
            Model model) {

        var coursePage = service.listCourses(page, size, category, status, search);
        model.addAttribute("courses", coursePage);
        model.addAttribute("currentPage", page);
        model.addAttribute("totalPages", coursePage.getTotalPages());
        model.addAttribute("selectedCategory", category);
        model.addAttribute("selectedStatus", status);
        model.addAttribute("search", search);
        model.addAttribute("allCategories", List.of("Category A","Category B","Category C","Category D"));
        model.addAttribute("allStatuses", List.of("Active","Inactive"));
        return "courses";
    }
}
