package com.example.swp_i1;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SwpI1Application {
    public static void main(String[] args) {
        SpringApplication.run(SwpI1Application.class, args);
    }
}
