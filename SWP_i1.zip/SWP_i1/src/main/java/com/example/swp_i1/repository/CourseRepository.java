package com.example.swp_i1.repository;

import com.example.swp_i1.model.Course;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;

public interface CourseRepository extends JpaRepository<Course, Long> {
    Page<Course> findByNameContainingIgnoreCaseAndCategoryContainingIgnoreCaseAndStatusContainingIgnoreCase(
            String name, String category, String status, Pageable pageable);
}
