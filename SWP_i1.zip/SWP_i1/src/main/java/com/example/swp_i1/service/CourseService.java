package com.example.swp_i1.service;

import com.example.swp_i1.model.Course;
import com.example.swp_i1.repository.CourseRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.*;
import org.springframework.stereotype.Service;

@Service
public class CourseService {
    @Autowired
    private CourseRepository repo;

    public Page<Course> listCourses(int page, int size,
                                    String category, String status, String search) {
        Pageable pageable = PageRequest.of(page, size, Sort.by("id"));
        String cat = (category == null ? "" : category);
        String st  = (status   == null ? "" : status);
        String q   = (search   == null ? "" : search);
        return repo.findByNameContainingIgnoreCaseAndCategoryContainingIgnoreCaseAndStatusContainingIgnoreCase(
                q, cat, st, pageable);
    }
}
